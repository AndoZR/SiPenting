<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?php echo $__env->yieldContent('title'); ?></title>

        <?php echo $__env->yieldPushContent('css'); ?>
        
        <link href="<?php echo e(asset('src/admin/css/styles.css')); ?>" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
  <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div id="layoutSidenav">
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div id="layoutSidenav_content">
          <main>
              <div class="container-fluid px-4">
                  <h1 class="mt-4"><?php echo $__env->yieldContent('sub-title'); ?></h1>
                  <ol class="breadcrumb mb-4">
                      <li class="breadcrumb-item active"><?php echo $__env->yieldContent('sub-title'); ?></li>
                  </ol>
                  <div class="row">
                    <?php echo $__env->yieldContent('content'); ?>
                  </div>
              </div>
          </main>
          <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
  </div>
</body>
      
<?php echo $__env->yieldPushContent('scripts'); ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('src/admin/js/scripts.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('src/admin/assets/demo/chart-area-demo.js')); ?>"></script>
<script src="<?php echo e(asset('src/admin/assets/demo/chart-bar-demo.js')); ?>"></script>

</html><?php /**PATH D:\Ando File 4 Kuliah\LOMBA BEA\SiPenting\SiPenting\resources\views\admin\app.blade.php ENDPATH**/ ?>