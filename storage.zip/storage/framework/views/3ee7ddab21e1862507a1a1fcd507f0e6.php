<footer class="py-4 bg-light mt-auto">
  <div class="container-fluid px-4">
      <div class="d-flex align-items-center justify-content-between small">
          <div class="text-muted">Copyright &copy; SIPENTING 2024</div>
          <div>
              <a href="#">Privacy Policy</a>
              &middot;
              <a href="#">Terms &amp; Conditions</a>
              &middot;
              <a target="_blank" href="https://wa.me/6281216532315">Kontak Pengembang</a>
          </div>
      </div>
  </div>
</footer><?php /**PATH D:\Ando File 4 Kuliah\LOMBA BEA\SiPenting\SiPenting\resources\views\admin\footer.blade.php ENDPATH**/ ?>