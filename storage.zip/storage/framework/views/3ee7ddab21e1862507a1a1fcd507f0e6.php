<br>
<footer class="footer">
    <div class="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0">
      <div class="flex items-center justify-start space-x-3">
        <div>
          © 2024, SiPenting App
        </div>
      </div>
      <a href="https://www.instagram.com/rce.candidate.east.java/?hl=en" target="_blank">
        <img class="flex" src="<?php echo e(asset('src/img/logo.png')); ?>" alt="" style="width: 50px; height: auto;">
      </a>    
    </div>
  </footer><?php /**PATH D:\Ando File 4 Kuliah\LOMBA BEA\SiPenting\SiPenting\resources\views\admin\footer.blade.php ENDPATH**/ ?>