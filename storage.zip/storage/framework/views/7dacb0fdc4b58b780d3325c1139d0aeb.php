<nav id="navbar-main" class="navbar is-fixed-top">
    <div class="navbar-menu" id="navbar-menu">
        <div class="navbar-end">
        <div class="navbar-item dropdown has-divider">
            <a class="navbar-link">
            <span class="icon"><i class="mdi mdi-menu"></i></span>
            <span>Sample Menu</span>
            <span class="icon">
                <i class="mdi mdi-chevron-down"></i>
            </span>
            </a>
            <div class="navbar-dropdown">
            <a href="profile.html" class="navbar-item">
                <span class="icon"><i class="mdi mdi-account"></i></span>
                <span>My Profile</span>
            </a>
            <a class="navbar-item">
                <span class="icon"><i class="mdi mdi-settings"></i></span>
                <span>Settings</span>
            </a>
            <a class="navbar-item">
                <span class="icon"><i class="mdi mdi-email"></i></span>
                <span>Messages</span>
            </a>
            <hr class="navbar-divider">
            <a class="navbar-item">
                <span class="icon"><i class="mdi mdi-logout"></i></span>
                <span>Log Out</span>
            </a>
            </div>
        </div>
    </div>
</nav><?php /**PATH D:\Ando File 4 Kuliah\LOMBA BEA\SiPenting\SiPenting\resources\views/admin/navbar.blade.php ENDPATH**/ ?>