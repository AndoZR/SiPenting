<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('sub-title', 'Home'); ?>

<?php $__env->startPush('css'); ?>
<style>
    .center-container {
    position: relative;
    height: 80vh; /* Mengatur tinggi container sesuai tinggi viewport */
}
.center-container img {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%); /* Menyelaraskan gambar di tengah-tengah */
    max-width: 100%; /* Menyesuaikan gambar dengan lebar container */
    height: auto; /* Menjaga rasio aspek gambar */
}

.center-container h1 {
    position: absolute;
    top: 10%; /* Jarak dari atas halaman */
    left: 50%;
    transform: translateX(-50%); /* Menyelaraskan teks di tengah secara horizontal */
    margin: 0;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="center-container">
    <h1>Selamat Datang di Dashboard!</h1>
    <img style="width: 300px; height: auto;" src="<?php echo e(asset('src/img/dashboard.svg')); ?>" alt="">
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ando File 4 Kuliah\LOMBA BEA\SiPenting\SiPenting\resources\views\admin\home.blade.php ENDPATH**/ ?>