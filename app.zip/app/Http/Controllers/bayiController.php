<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\bayi;
use Illuminate\Http\Request;
use App\Helpers\ResponseFormatter;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Auth\Events\Validated;
use Illuminate\Support\Facades\Validator;

class bayiController extends Controller
{
    public function index(){
        $id = Auth::user()->id;
        $dataBayi = bayi::get();
        return ResponseFormatter::success($dataBayi,'Data Bayi Berhasil Didapat!');
    }

    public function storeBayi(Request $request){
        $validator = Validator::make($request->all(), [
            'nama' => 'required|string',
            'tanggalLahir' => 'required|date',
            'kelamin' => 'required|string',
        ]);

        if ($validator->fails()) {
            return ResponseFormatter::error(null,$validator->errors(),422);
        };

        try {
            $test = bayi::create([
                'nama' => $request->nama,
                'tanggalLahir' => $request->tanggalLahir,
                'kelamin' => $request->kelamin,
                'id_users' => Auth::user()->id,
            ]);

            return ResponseFormatter::success($test, "Data Bayi Berhasil Dibuat!");
        } catch (Exception $e) {
            Log::error($e->getMessage());
            return ResponseFormatter::error($e->getMessage(), "Data gagal disimpan. Kesalahan Server", 500);
        }
    }

    public function updateBayi(Request $request){
        $validator = Validator::make($request->all(), [
            'nama' => 'required|string',
            'tanggalLahir' => 'required|date',
            'kelamin' => 'required|string',
        ]);

        if ($validator->fails()) {
            return ResponseFormatter::error(null,$validator->errors(),422);
        };

        try {
            $test = bayi::find($request->idBayi);
            $test->update([
                'nama' => $request->nama,
                'tanggalLahir' => $request->tanggalLahir,
                'kelamin' => $request->kelamin,
            ]);

            return ResponseFormatter::success($test, "Data Bayi Berhasil Diubah!");
        } catch (Exception $e) {
            Log::error($e->getMessage());
            return ResponseFormatter::error($e->getMessage(), "Data gagal disimpan. Kesalahan Server", 500);
        }
    }

    public function deleteBayi(Request $request){
        try{
            $test = bayi::find($request->idBayi);
            $test->delete();
            return ResponseFormatter::success("Data Bayi Berhasil Dihapus!");
        } catch (Exception $e) {
            Log::error($e->getMessage());
            return ResponseFormatter::error($e->getMessage(), "Data gagal dihapus. Kesalahan Server", 500);
        }
    }
}
