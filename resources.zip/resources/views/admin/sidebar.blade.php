<aside class="aside is-placed-left is-expanded">
    <div class="aside-tools">
      <div>
        Admin <b class="font-black">One</b>
      </div>
    </div>
    <div class="menu is-menu-main">
      <p class="menu-label">General</p>
      <ul class="menu-list">
        <li class="active">
          <a href="index.html">
            <span class="icon"><i class="mdi mdi-desktop-mac"></i></span>
            <span class="menu-item-label">Dashboard</span>
          </a>
        </li>
      </ul>
      <p class="menu-label">Menu</p>
      <ul class="menu-list">
        <li class="--set-active-tables-html">
          <a href="{{ route('artikel.index') }}">
            <span class="icon"><i class="mdi mdi-book-open-page-variant"></i></span>
            <span class="menu-item-label">Artikel</span>
          </a>
        </li>
      </ul>
    </div>
</aside>